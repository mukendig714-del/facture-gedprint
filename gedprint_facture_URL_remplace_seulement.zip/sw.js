// Service worker GedPrint : permet l'installation comme une vraie application
// et garde la facture disponible même avec une mauvaise connexion.
const CACHE = 'gedprint-v7';
const FILES = ['./', './index.html', './manifest.json', './icon-192.png', './icon-512.png'];

self.addEventListener('install', function (event) {
    // Un fichier manquant ne doit jamais empêcher l'installation du service worker
    event.waitUntil(
        caches.open(CACHE).then(function (cache) {
            return Promise.all(FILES.map(function (f) { return cache.add(f).catch(function () {}); }));
        }).then(function () { return self.skipWaiting(); })
    );
});

self.addEventListener('activate', function (event) {
    event.waitUntil(
        caches.keys().then(function (keys) {
            return Promise.all(keys.filter(function (k) { return k !== CACHE; }).map(function (k) { return caches.delete(k); }));
        }).then(function () { return self.clients.claim(); })
    );
});

// Réseau d'abord (toujours la dernière version), cache en secours.
// Cloudinary, WhatsApp et les autres sites ne sont jamais touchés.
self.addEventListener('fetch', function (event) {
    const req = event.request;
    if (req.method !== 'GET' || new URL(req.url).origin !== self.location.origin) return;
    event.respondWith(
        fetch(req).then(function (resp) {
            if (resp && resp.ok) {
                const copy = resp.clone();
                caches.open(CACHE).then(function (c) { c.put(req, copy); });
            }
            return resp;
        }).catch(function () {
            return caches.match(req).then(function (r) { return r || caches.match('./index.html'); });
        })
    );
});
